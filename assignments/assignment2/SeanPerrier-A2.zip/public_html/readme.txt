Student Name:  Sean Perrier
Student Email: sean_perrier@student.uml.edu
Assignment #2 - Creating Your First Web Page


Files Included in Zip File:
'readme.txt'
'index.html'
'css/assignment2.css'
'instructions/Assignment1.pdf'
'instructions/Assignment2.pdf'
'assignments/assignment1/SeanPerrier-A1.pdf'
'assignments/assignment2/SeanPerrier-A2.zip'


Live URL for this assignment can be found here:
http://weblab.cs.uml.edu/~sperrier/

Validator Used (No Issues Found):
https://validator.w3.org/